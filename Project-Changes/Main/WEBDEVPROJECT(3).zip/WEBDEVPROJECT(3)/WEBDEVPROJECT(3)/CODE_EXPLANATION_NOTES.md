# Study Notes: Learn This Project Step by Step

This document is written as teaching notes, not just a file map.

Use it like this:
1. Open this note on one side.
2. Open the linked code line on the other side.
3. Read what it does, then test it in browser/devtools.

Files:
- [html/index.html](html/index.html)
- [static/css/stylesheet.css](static/css/stylesheet.css)

## 1) Big Picture First

Your app is a single-page JavaScript app.

Core idea:
1. Load JSON data with `fetch`.
2. Convert that data into a list of records in memory (`allExamples`).
3. Render those records as cards or table depending on screen size.
4. Let user add/edit/delete records and tags.
5. Re-render after every change.

Main start point:
- [loadData call](html/index.html#L1224)

## 2) HTML: What Each Screen Part Is For

### A) App shell
- [Page setup](html/index.html#L1): Browser metadata, title, CSS link.
- [Hamburger button](html/index.html#L11): Toggles controls panel.
- [Header](html/index.html#L14): Title + tag manager shortcut.

Why this matters:
- Gives user an obvious starting structure.

### B) Main controls area
- [Controls section](html/index.html#L25): Sort dropdown + Add button.

Why this matters:
- Sorting and adding are primary user tasks.

### C) Add form
- [Add form section](html/index.html#L54)

What it teaches:
1. How to collect user input.
2. How to show validation feedback under each field.
3. How to preview images before saving.

### D) Edit form
- [Edit form section](html/index.html#L145)

What it teaches:
1. How to prefill a form with existing data.
2. How to edit or remove image URLs in-place.

### E) Data display areas
- [Card container](html/index.html#L205): Used in non-desktop layout.
- [Table container](html/index.html#L208): Used in desktop layout.

### F) Modals
- [Details modal](html/index.html#L228): Full details for one row.
- [Delete modal](html/index.html#L245): Confirm deletion.
- [Tag manager modal](html/index.html#L265): Manage tag list.

Why modals:
- Keep user on same page while showing focused task.

## 3) JavaScript: Teach-Through by Function

### A) State and constants
- [JSON path](html/index.html#L308)
- [Data state](html/index.html#L311)
- [UI state](html/index.html#L316)

How to think about this:
- `allExamples` is your “source of truth” in memory.
- UI is always redrawn from this data.

### B) Tiny helper functions

- [getDefaultFavorite](html/index.html#L324)
What: returns `yes` or `no` randomly.
Why: requirement says every fetched record gets random favorite.

- [getDefaultRating](html/index.html#L329)
What: returns random integer from 0 to 5.
Why: requirement says every fetched record gets random rating.

- [getFavoriteIcon](html/index.html#L334)
What: turns yes/no into heart character.
Why: user-friendly display.

- [getRatingStars](html/index.html#L339)
What: turns number into star string.
Why: visual rating output.

- [cleanTag](html/index.html#L344)
What: trims spaces around tag text.
Why: prevents accidental space mismatches.

- [getCleanTagList](html/index.html#L349)
What: split comma text -> clean unique tags.
Why: avoids duplicate tags and empty entries.

- [targetTextToNumber](html/index.html#L367)
What: converts target text to number for sorting.
Why: numeric sorts must compare numbers, not text.

- [showError](html/index.html#L374)
What: writes error text to a specific error element.
Why: clear feedback per input.

- [clearAllErrors](html/index.html#L383)
What: wipes all previous error messages.
Why: avoid stale errors after correction.

- [isValidTargetNumber](html/index.html#L391)
What: regex check for target format.
Why: enforce consistent input shape.

- [isValidUrl](html/index.html#L396)
What: URL constructor check.
Why: reject invalid image links.

### C) Data load and normalization

- [loadData](html/index.html#L407)
What this function does in order:
1. `fetch` JSON file.
2. Convert nested JSON into flat `allExamples` array.
3. Add random `favorite` and `rating` to each example.
4. Rebuild tags and render UI.
5. Show error message if fetch fails.

Why flatten data:
- Rendering cards/table is easier from one flat array.

- [rebuildAllTags](html/index.html#L451)
What:
1. Clear tag set.
2. Read tags from all examples.
3. Add custom tags.

Why:
- Tag validation and tag manager must always know current valid tags.

### D) Sorting engine

- [getFilteredAndSorted](html/index.html#L462)
What:
1. Copy `allExamples`.
2. Sort based on selected option.

Why copy first:
- Keep original state stable while sorting a working array.

Sorting cases you have:
- title asc/desc
- target asc/desc
- tags asc/desc
- favorite asc/desc
- rating asc/desc
- images asc/desc

### E) Responsive rendering controller

- [updateDisplay](html/index.html#L534)
What:
1. Check screen mode.
2. Update controls visibility.
3. Render cards or table.

- [updateControlsMenu](html/index.html#L544)
What:
- Shows controls only when hamburger state is open.

- [checkIsDesktop](html/index.html#L550)
What:
- `isDesktop = window.innerWidth > 768`.
- Shows table on desktop, cards otherwise.

### F) UI render functions

- [renderCards](html/index.html#L561)
What:
1. Clear card container.
2. Build one card per example.
3. Inject tags and images.
4. Add Edit/Delete buttons.

Key concept:
- This function does not change data, it only paints UI.

- [renderTable](html/index.html#L629)
What:
1. Clear table body.
2. Build one row per example.
3. Add Edit/Delete button per row.
4. Row click opens details modal.

- [renderDetailsModal](html/index.html#L671)
What:
- Builds full details markup for one example.

### G) Modal open/close control

- [openDetailsModal](html/index.html#L703)
- [closeDetailsModal](html/index.html#L711)
- [openDeleteModal](html/index.html#L715)
- [closeDeleteModal](html/index.html#L723)

Learning point:
- Modals are controlled by `style.display`.

### H) Validation and form extraction

- [validateTagsField](html/index.html#L730)
What:
- Ensures tags are not empty and every tag exists in `allTags`.

- [getAddFormData](html/index.html#L753)
- [getEditFormData](html/index.html#L766)
What:
- Read and package form values into one object.

Why this pattern is good:
- Validation and save logic can reuse same data object.

- [validateAddForm](html/index.html#L788)
- [validateEditForm](html/index.html#L827)
What:
1. Clear old errors.
2. Validate each field.
3. Show specific message on failure.
4. Return true/false.

### I) CRUD for examples

- [addExample](html/index.html#L869)
Flow:
1. Validate add form.
2. Build new object.
3. Push to `allExamples`.
4. Rebuild tags.
5. Re-render.
6. Reset/hide add form.

- [editExample](html/index.html#L899)
Flow:
1. Find selected example.
2. Prefill edit inputs.
3. Render current images in editable list.
4. Show only edit section.

- [saveEdit](html/index.html#L936)
Flow:
1. Validate edit form.
2. Find example by id.
3. Overwrite fields.
4. Rebuild tags and re-render.
5. Hide edit section.

- [deleteExample](html/index.html#L959)
Flow:
1. Find index by `deleteTargetId`.
2. Remove from array.
3. Rebuild tags and re-render.
4. Close delete modal.

### J) Image helpers for forms

- [addNewImage](html/index.html#L970)
What:
- Validate URL, then append image preview block to Add form.

- [addNewEditImage](html/index.html#L994)
What:
- Same idea for Edit form, includes editable URL input.

### K) Tag manager CRUD

- [openTagManagerModal](html/index.html#L1020)
- [closeTagManagerModal](html/index.html#L1026)

- [renderTagManager](html/index.html#L1031)
What:
- Paints all tags with Edit/Delete buttons.

- [renameTag](html/index.html#L1051)
What:
1. Prompt for new name.
2. Validate.
3. Replace old tag in every example.
4. Update custom tag set.
5. Rebuild and re-render.

- [addNewTag](html/index.html#L1099)
What:
- Validate and add to tag sets, then re-render.

- [deleteTag](html/index.html#L1133)
What:
- Confirm delete, remove tag from sets and all examples, re-render.

### L) Event listeners and app start

- [Listeners block](html/index.html#L1148)

This section connects user actions to functions:
1. Buttons -> add/edit/delete/tag/image functions.
2. Add/Edit cancel buttons -> show/hide sections.
3. Sort dropdown -> update sorting.
4. Hamburger -> toggle controls panel.
5. Resize -> refresh responsive display.

- [Startup call](html/index.html#L1224): calls `loadData()` once.

## 4) CSS: Teach-Through by Block

### A) Theme and reset
- [Variables](static/css/stylesheet.css#L2): colors reused through file.
- [Universal box sizing](static/css/stylesheet.css#L7): makes width/padding sizing predictable.
- [Base page styles](static/css/stylesheet.css#L11)

### B) Main layout and buttons
- [Main content padding](static/css/stylesheet.css#L20)
- [Header layout](static/css/stylesheet.css#L25)
- [Button baseline](static/css/stylesheet.css#L54)
- [Button variants](static/css/stylesheet.css#L67)
- [Hamburger fixed placement](static/css/stylesheet.css#L87)

### C) Controls and forms
- [Controls container](static/css/stylesheet.css#L95)
- [Filter group layout](static/css/stylesheet.css#L105)
- [Form panels](static/css/stylesheet.css#L119)
- [Form vertical flow](static/css/stylesheet.css#L127)
- [Input sizing](static/css/stylesheet.css#L140)
- [Error message style](static/css/stylesheet.css#L152)

### D) Cards and images
- [Card grid](static/css/stylesheet.css#L190)
- [Card shell/header/meta](static/css/stylesheet.css#L196)
- [Tag/target badge style](static/css/stylesheet.css#L232)
- [Image grids](static/css/stylesheet.css#L169)

### E) Table
- [Table wrapper and layout](static/css/stylesheet.css#L249)
- [Row/cell style](static/css/stylesheet.css#L261)
- [Clickable row cursor](static/css/stylesheet.css#L273)

### F) Modals
- [Overlay](static/css/stylesheet.css#L283)
- [Modal box](static/css/stylesheet.css#L294)
- [Header/footer](static/css/stylesheet.css#L309)

### G) Tag manager and hidden defaults
- [Tag manager list/item](static/css/stylesheet.css#L356)
- [Initially hidden sections/modals](static/css/stylesheet.css#L376)

### H) Responsive breakpoints
- [Mobile under 600](static/css/stylesheet.css#L386)
What changes:
1. Form/control rows stack vertically.
2. Table hidden.

- [Tablet 600-768](static/css/stylesheet.css#L413)
What changes:
1. Cards show in two columns.
2. Table hidden.

- [Desktop 769+](static/css/stylesheet.css#L423)
What changes:
1. Card grid hidden.
2. Table shown.

## 5) How to Explain This in an Exam or Viva

Say this structure:
1. "My data source is JSON fetched in loadData."
2. "I normalize data and store it in allExamples."
3. "UI is re-rendered using updateDisplay after every data change."
4. "Cards are for small screens, table is for desktop."
5. "I use modals for row details and delete confirmation."
6. "Add/Edit forms validate inputs and tags against current tag list."
7. "Tag manager supports add, rename, delete and updates dataset tags."

## 6) Short Practice Tasks

1. Change default sort to rating-desc and explain where you changed it.
Hint: [currentSort state](html/index.html#L316)

2. Make title minimum length 5 instead of 3.
Hints: [validateAddForm](html/index.html#L788), [validateEditForm](html/index.html#L827)

3. Show only first image in table (keep full images in details modal).
Hint: [renderTable](html/index.html#L629)

4. Change desktop cutoff from 768 to 900.
Hints: [checkIsDesktop](html/index.html#L550), [desktop media query](static/css/stylesheet.css#L423)

## 7) Further Reading (Best Links)

### JavaScript and DOM
- JS Guide: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide
- Arrays: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array
- DOM Intro: https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model/Introduction
- Events: https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener

### Fetch, JSON, Validation
- Fetch: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
- JSON: https://developer.mozilla.org/en-US/docs/Learn/JavaScript/Objects/JSON
- Regex: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Regular_expressions

### CSS and Responsive
- CSS Basics: https://developer.mozilla.org/en-US/docs/Learn/CSS/First_steps
- Media Queries: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries/Using_media_queries
- Flexbox: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout/Basic_concepts_of_flexbox
- Grid: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout

### HTML Forms
- Forms Guide: https://developer.mozilla.org/en-US/docs/Learn/Forms

## 8) One-Line Memory Hook

"Fetch JSON -> store in allExamples -> render cards/table -> user edits data -> validate -> update allExamples -> render again."
